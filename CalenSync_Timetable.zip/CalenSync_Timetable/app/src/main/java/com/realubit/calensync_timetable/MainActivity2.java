import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import com.realubit.calensync_timetable.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView taskListView;
    private ArrayList<String> tasks;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskListView = findViewById(R.id.taskListView);
        Button addTaskButton = findViewById(R.id.addTaskButton);

        // Initialize task list
        tasks = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);
        taskListView.setAdapter(adapter);

        // Navigate to Task Input Screen
        addTaskButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            startActivityForResult(intent, 1);
        });

        // Handle item clicks
        taskListView.setOnItemClickListener((parent, view, position, id) -> {
            // Show task details
            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            intent.putExtra("task", tasks.get(position));
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String newTask = data.getStringExtra("newTask");
            tasks.add(newTask);
            adapter.notifyDataSetChanged();
        }
    }
}
